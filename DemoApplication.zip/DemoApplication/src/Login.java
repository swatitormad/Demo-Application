

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
	    out.print("<html>");
	    out.print("<body>");
	    out.print("<form action='Validate'>");
	    out.print("<h1>welcome to login page</h1>");
	    String msgtype=request.getParameter("msg");
	    if(msgtype!=null && msgtype.equals("error"))
	    {
	    	out.print("<font color='red'><h3>Invalid user name and password</h3></font>");
	    }
	    else if(msgtype!=null && msgtype.equals("success"))
	    {
	    
	    	out.print("<font color='green'><h3>You have logged out sucessfully</h3></font>");
	    }
	    out.print("<br>");
	    out.print("Enter username:<input type='text' name='UN'>");
	    out.print("<br><br>");
	    out.print("Enter password:<input type='password' name='PASS'>");
		out.print("<br><br>");
		out.print("<input type='submit' value='next'>");
	    out.print("</form>");
		out.print("</body>");
		out.print("</html>");
		}


}


