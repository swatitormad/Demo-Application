

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user=request.getParameter("UN");
		String password=request.getParameter("PASS");
			PrintWriter out=response.getWriter();
			
			if("swati".equals(user) && "swati@123".equals(password))
			{
				response.sendRedirect("Home");
			}
			else
			{
				response.sendRedirect("Login?msg=error");
			}
	}


	

}
