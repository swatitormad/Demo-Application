

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Home")
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
	    HttpSession s=request.getSession();//create session
		String name=(String)s.getAttribute("uname");//get use detail from session
	    out.print("<html>");
	    out.print("<body>");
	    out.print("<h1>welcome user</h1>");
	    out.print("<h3><a href='Logout'>Logout</a></h3>");
	    out.print("</html>");
	    out.print("</body>");
	}
}


